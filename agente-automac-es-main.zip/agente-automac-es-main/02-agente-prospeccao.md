# Agente de prospecção ativa

**Onde rodou:** Atria Jr, empresa júnior de consultoria em telecomunicações da UNICAMP
**Status:** em produção

## O problema

A prospecção era inteiramente manual. Alguém abria o navegador, procurava empresas da região, olhava site por site para decidir se fazia sentido, montava uma planilha e escrevia cada abordagem do zero. Levava horas e rendia poucos contatos, e a qualidade dependia de quem estava fazendo naquele dia.

## O fluxo

```mermaid
flowchart TD
    A[Critérios de busca:<br/>região, porte, segmento] --> B[Busca por APIs de terceiros]
    B --> C[Consolida e remove duplicados<br/>contra o que já está no CRM]
    C --> D[Enriquece: site, contato, atividade]
    D --> E{Qualificação<br/>com LLM}
    E -->|Fora do perfil| F[Descarta e registra o motivo]
    E -->|Dentro do perfil| G[Gera a abordagem<br/>citando o contexto da empresa]
    G --> H[Revisão humana antes do envio]
    H --> I[Registro no CRM com score e motivo]
```

## Decisões

**A qualificação devolve o motivo, não só um sim ou não.** O LLM recebe os critérios do time e responde se a empresa se encaixa e por quê. O motivo registrado é o que permitiu ajustar os critérios depois, olhando o que estava sendo descartado por engano.

**Revisão humana antes do envio.** O agente gera a abordagem, mas quem envia é uma pessoa. Mensagem fria enviada automaticamente em nome de uma empresa júnior é risco de queimar a marca por um erro do modelo.

**Deduplicar contra o CRM antes de qualificar.** Rodar o LLM em empresa que já estava no pipeline era desperdício de chamada e gerava abordagem repetida para quem já tinha sido contatado.

## Resultado

- A prospecção deixou de depender de alguém repetindo a mesma busca toda semana
- Junto com a reestruturação do processo comercial, foi fechado o maior contrato do ano: **R$ 30 mil**, cerca de **73% da meta anual** da empresa

## Stack

n8n · GPT · APIs REST de terceiros · webhooks · CRM por API
