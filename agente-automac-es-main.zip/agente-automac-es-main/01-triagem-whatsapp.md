# Triagem de atendimento no WhatsApp

**Onde rodou:** Atria Jr, empresa júnior de consultoria em telecomunicações da UNICAMP
**Status:** em produção

## O problema

Toda mensagem nova no WhatsApp da empresa esperava em média quatro horas por uma primeira resposta. O time era de estudantes, com aula durante o dia, e ninguém ficava olhando a caixa.

Pior que a demora: a maior parte das mensagens era sempre a mesma coisa. Preço, prazo, o que a consultoria faz, como funciona o processo. Quem respondia gastava o tempo digitando de novo o que já tinha digitado na semana anterior, e o contato que realmente era uma oportunidade ficava na fila atrás disso.

## O fluxo

```mermaid
flowchart TD
    A[Mensagem no WhatsApp] --> B[Webhook no n8n]
    B --> C[Normaliza e identifica o contato]
    C --> D{Classificação<br/>com LLM}
    D -->|Dúvida recorrente| E[Monta a resposta<br/>a partir da base de respostas]
    E --> F[Envia pelo WhatsApp]
    D -->|Oportunidade ou<br/>caso específico| G[Resume a conversa<br/>e extrai o contexto]
    G --> H[Notifica a pessoa responsável<br/>com o resumo pronto]
    H --> I[Registro no CRM]
    F --> I
```

## Decisões

**Classificar antes de responder.** O primeiro desenho mandava tudo direto para o LLM gerar uma resposta livre. Funcionava mal: o modelo inventava prazo e preço. Separei em duas etapas — primeiro classificar a intenção, depois responder só o que estivesse na base de respostas aprovadas. O que não se encaixa não é respondido pela IA, é encaminhado.

**Encaminhar com contexto, não só avisar.** Quando a conversa vai para uma pessoa, ela recebe o resumo do que o contato quer, não um "tem mensagem nova". Isso é o que fez a passagem para o humano ser rápida.

**Registrar sempre.** Respondido pela IA ou por pessoa, o atendimento cai no CRM pelo mesmo caminho. Sem isso, metade do histórico sumiria.

## Resultado

- Primeira resposta caiu de cerca de **4 horas para menos de 1 minuto**
- **70%** das dúvidas repetitivas passaram a ser resolvidas sem intervenção humana
- O time parou de transcrever atendimento para o CRM à mão

## Stack

n8n · Evolution API (WhatsApp) · GPT · webhooks · CRM por API
