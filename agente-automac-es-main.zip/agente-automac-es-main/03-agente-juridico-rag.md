# Agente jurídico com RAG

**Onde rodou:** MVP de um SaaS para escritório de advocacia
**Status:** MVP entregue

## O problema

Duas dores no mesmo canal de WhatsApp.

Do lado de fora, leads chegavam a qualquer hora, inclusive de madrugada, e esfriavam antes de alguém conseguir responder e entender do que se tratava o caso.

Do lado de dentro, os advogados precisavam consultar processos o tempo todo e isso significava abrir o sistema, achar o processo certo e ler até encontrar a informação. Uma pergunta simples, como em que fase está determinado processo, custava minutos.

O agente resolve os dois pelo mesmo canal: atende e qualifica quem chega de fora, e responde aos advogados sobre os processos consultando a base do escritório.

## O fluxo

```mermaid
flowchart TD
    A[Mensagem no WhatsApp] --> B[Webhook no n8n]
    B --> C[Entra na fila]
    C --> D{Quem está falando?}
    D -->|Lead| E[Atendimento e qualificação:<br/>entende o caso e coleta os dados]
    E --> F[Lead qualificado<br/>entregue ao escritório]
    D -->|Advogado| G[Gera o embedding da pergunta]
    G --> H[(Supabase<br/>processos indexados)]
    H --> I[Recupera os trechos relevantes]
    I --> J[LLM responde<br/>ancorado nos trechos]
    J --> K[Resposta com a origem da informação]
```

## Decisões

**Fila entre o webhook e o processamento.** Sem isso, uma rajada de mensagens simultâneas derruba o fluxo ou estoura o limite da API do modelo. Com a fila, a entrada fica desacoplada do processamento e a arquitetura aguenta mais de 500 conversas ao mesmo tempo sem perder mensagem.

**Resposta ancorada no trecho recuperado.** Em jurídico, modelo inventando informação sobre processo não é um erro aceitável. O prompt obriga a responder apenas a partir dos trechos recuperados e a dizer que não encontrou quando a base não cobre a pergunta.

**Indexação dos processos no Supabase.** O conteúdo dos processos foi quebrado em trechos e indexado com embeddings no mesmo Postgres onde o resto do sistema já vivia, evitando mais um serviço na arquitetura do MVP.

**GPT e Llama.** Os dois foram usados no projeto, o que deixou claro o custo de amarrar os prompts a um único provedor. Em um próximo, a camada de modelo entraria atrás de uma interface própria desde o começo.

## Resultado

- Arquitetura para mais de **500 conversas simultâneas**
- Latência média abaixo de **3 segundos**
- **+25%** na conversão de leads qualificados, pelo atendimento imediato e com contexto
- **R$ 20 mil por ano** de economia estimada com a triagem inicial

## Stack

n8n · GPT e Llama · RAG com embeddings · Supabase (PostgreSQL) · Evolution API (WhatsApp) · filas e processamento assíncrono
