# Agentes e automações

Três sistemas que construí com n8n e LLMs e que entraram em operação: atendimento, prospecção e consulta a processos jurídicos.

Os fluxos em si pertencem às empresas onde rodaram e carregam credenciais e dados de clientes, então o que está aqui é a arquitetura: o problema, o desenho do fluxo, as decisões técnicas e o resultado medido.

| Caso | O que faz | Resultado |
|---|---|---|
| [Triagem de atendimento no WhatsApp](01-triagem-whatsapp.md) | Classifica a mensagem que chega, responde o que é repetitivo e encaminha o resto | Primeira resposta de 4h para menos de 1 min; 70% resolvido sem humano |
| [Agente de prospecção ativa](02-agente-prospeccao.md) | Busca empresas, qualifica com LLM e gera a abordagem | Prospecção deixou de ser manual |
| [Agente jurídico com RAG](03-agente-juridico-rag.md) | Atende leads e responde sobre processos consultando a base do escritório | 500+ conversas simultâneas, resposta em menos de 3s |

**Stack recorrente:** n8n · GPT e Llama · Supabase (PostgreSQL + pgvector) · Evolution API (WhatsApp) · APIs REST e webhooks · filas

---

Joyce Gomes de Queiroz — [LinkedIn](https://linkedin.com/in/--joycequeiroz)
